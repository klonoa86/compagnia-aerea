-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versione server:              5.7.25-log - MySQL Community Server (GPL)
-- S.O. server:                  Win64
-- HeidiSQL Versione:            10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dump dei dati della tabella compagnia_aerea.aereo: ~0 rows (circa)
/*!40000 ALTER TABLE `aereo` DISABLE KEYS */;
/*!40000 ALTER TABLE `aereo` ENABLE KEYS */;

-- Dump dei dati della tabella compagnia_aerea.cliente: ~0 rows (circa)
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;

-- Dump dei dati della tabella compagnia_aerea.prenotazione: ~0 rows (circa)
/*!40000 ALTER TABLE `prenotazione` DISABLE KEYS */;
/*!40000 ALTER TABLE `prenotazione` ENABLE KEYS */;

-- Dump dei dati della tabella compagnia_aerea.volo: ~0 rows (circa)
/*!40000 ALTER TABLE `volo` DISABLE KEYS */;
/*!40000 ALTER TABLE `volo` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
